/*
 * serialization.h
 * RPOS Serialization Utilities
 *
 * Created By Tony Huang (cnwzhjs@gmail.com) at 2014-12-11
 * Copyright 2014 (c) Shanghai Slamtec Co., Ltd.
 */

#pragma once

#include "json_serialization.h"